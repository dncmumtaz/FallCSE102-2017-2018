#include <stdio.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>

typedef enum{S=1,B,P,T,M,E}b_type;

typedef struct block{
	char text[12]; 
	int data, pos_x, pos_y, jump_x, jump_y;
	b_type type;
}blockk;
void write(blockk board[][10], int *x, int *y);
int single(blockk board[][10], int *x, int *y);

int main(){
	int x=9 , y=9  ;
	
	
	srand(time(NULL));
	
	blockk board[10][10];
	single(board,&x, &y);


	return 0;

}

void write(blockk board[][10], int *x, int *y){

  
	int i,j;

	
	board[0][0].data = 91;
	strcpy(board[0][0].text," ");	
	board[0][0].jump_x = 0;
	board[0][0].jump_y = 0;
	board[0][0].type = E;
	
	board[0][1].data = 92;
	strcpy(board[0][1].text," ");
	board[0][1].jump_x = 0;
	board[0][1].jump_y = 0;
	board[0][1].type = E;
	
	board[0][2].data = -4;
	strcpy(board[0][2].text," ");
	board[0][2].jump_x = 1;
	board[0][2].jump_y = 7;
	board[0][2].type = T;
	
	board[0][3].data = 94;
	strcpy(board[0][3].text," ");
	board[0][3].jump_x = 0;
	board[0][3].jump_y = 0;
	board[0][3].type = E;
	
	board[0][4].data = 95;
	strcpy(board[0][4].text," ");
	board[0][4].jump_x = 0;
	board[0][4].jump_y = 0;
	board[0][4].type = E;
	
	board[0][5].data = 96;
	strcpy(board[0][5].text," ");
	board[0][5].jump_x = 0;
	board[0][5].jump_y = 0;
	board[0][5].type = E;
	
	board[0][6].data = 97;
	strcpy(board[0][6].text," ");
	board[0][6].jump_x = 0;
	board[0][6].jump_y = 0;
	board[0][6].type = E;
	
	board[0][7].data = -1;
	strcpy(board[0][7].text , "{72}");
	board[0][7].jump_x = 2;
	board[0][7].jump_y = 1;
    board[0][7].type = S;
    
	board[0][8].data = -1;
	strcpy(board[0][8].text , "{56}");
	board[0][8].jump_x = 4;
	board[0][8].jump_y = 5;
    board[0][8].type =S;
    
	board[0][9].data = 100;
	strcpy(board[0][9].text ,"(FINISH)");
	board[0][9].jump_x = 0;
	board[0][9].jump_y = 0;
	board[0][9].type = E;
///////////////////////////////////////////////////
	
	board[1][0].data = 90;
	strcpy(board[1][0].text," ");
	board[1][0].jump_x = 0;
	board[1][0].jump_y = 0;
	board[1][0].type = E;
	
	
	board[1][1].data = -5;
	strcpy(board[1][1].text , "{94}");
	board[1][1].jump_x = 0;
	board[1][1].jump_y = 3;
	board[1][1].type = M;
	
	board[1][2].data = 88;	
	strcpy(board[1][2].text ," ");
	board[1][2].jump_x = 0;
	board[1][2].jump_y = 0;
	board[1][2].type = E;
	
	board[1][3].data = 87;
	strcpy(board[1][3].text ," ");
	board[1][3].jump_x = 0;
	board[1][3].jump_y = 0;
	board[1][3].type = E;
	
	board[1][4].data = 86;
	strcpy(board[1][4].text," ");
	board[1][4].jump_x = 0;
	board[1][4].jump_y = 0;
	board[1][4].type = E;
	
	board[1][5].data = -3;
	strcpy(board[1][5].text ," ");
	board[1][5].jump_x = 0;
	board[1][5].jump_y = 0;
	board[1][5].type = P;
	
	board[1][6].data = 84;
	strcpy(board[1][6].text ," ");
	board[1][6].jump_x = 0;
	board[1][6].jump_y = 0;
	board[1][6].type = E;
	
	board[1][7].data = 83;
	strcpy(board[1][7].text ," ");
	board[1][7].jump_x = 0;
	board[1][7].jump_y = 0;
    board[1][7].type = E;
    
	board[1][8].data = -2;
	strcpy(board[1][8].text," ");
	board[1][8].jump_x = 1;
	board[1][8].jump_y = 3;
    board[1][8].type = B;

	board[1][9].data = 81;
	strcpy(board[1][9].text," ");
	board[1][9].jump_x = 0;
	board[1][9].jump_y = 0;
    board[1][9].type = E;	
///////////////////////////

	board[2][0].data = 71;
	strcpy(board[2][0].text ," ");
	board[2][0].jump_x = 0;
	board[2][0].jump_y = 0;
	board[2][0].type = E;
	
	board[2][1].data = 72;
	strcpy(board[2][1].text ," ");
	board[2][1].jump_x = 0;
	board[2][1].jump_y = 0;
	board[2][1].type = E;
	
	board[2][2].data = -1;	
	strcpy(board[2][2].text ,"{68}");
	board[2][2].jump_x = 0;
	board[2][2].jump_y = 0;
	board[2][2].type = S;
	
	board[2][3].data = 74;
	strcpy(board[2][3].text ," ");
	board[2][3].jump_x = 0;
	board[2][3].jump_y = 0;
	board[2][3].type = E;
	
	board[2][4].data = 75;
	strcpy(board[2][4].text," ");
	board[2][4].jump_x = 0;
	board[2][4].jump_y = 0;
	board[2][4].type = E;
	
	board[2][5].data = -5;
	strcpy(board[2][5].text ,"{83}");
	board[2][5].jump_x = 1;
	board[2][5].jump_y = 8;
	board[2][5].type = M;
	
	board[2][6].data = 77;
	strcpy(board[2][6].text," ");
	board[2][6].jump_x = 0;
	board[2][6].jump_y = 0;
	board[2][6].type = E;
	
	board[2][7].data = 78;
	strcpy(board[2][7].text," ");
	board[2][7].jump_x = 0;
	board[2][7].jump_y = 0;
    board[2][7].type = E;
    
	board[2][8].data = -4;
	strcpy(board[2][8].text ," ");
	board[2][8].jump_x = 2;
	board[2][8].jump_y = 3;
    board[2][8].type = T;
    
	board[2][9].data = 80;
	strcpy(board[2][9].text," ");
	board[2][9].jump_x = 0;
	board[2][9].jump_y = 0;
	board[2][9].type = E;
///////////////////////////

	board[3][0].data = 70;
	strcpy(board[3][0].text," ");	
	board[3][0].jump_x = 0;
	board[3][0].jump_y = 0;
	board[3][0].type = E;
	
	board[3][1].data = -5;
	strcpy(board[3][1].text ,"{77}");
	board[3][1].jump_x = 2;
	board[3][1].jump_y = 6;
	board[3][1].type = M;
	
	board[3][2].data = 68;	
	strcpy(board[3][2].text ," ");
	board[3][2].jump_x = 0;
	board[3][2].jump_y = 0;
	board[3][2].type = E;
	
	board[3][3].data = 67;
	strcpy(board[3][3].text ," ");
	board[3][3].jump_x = 0;
	board[3][3].jump_y = 0;
	board[3][3].type = E;
	
	board[3][4].data = -2;
	strcpy(board[3][4].text ," ");
	board[3][4].jump_x = 2;   
	board[3][4].jump_y = 9;	
	board[3][4].type = B;
	
	board[3][5].data = 65;
	strcpy(board[3][5].text," ");
	board[3][5].jump_x = 0;
	board[3][5].jump_y = 0;
	board[3][5].type = E;
	
	board[3][6].data = 64;
	strcpy(board[3][6].text ," ");
	board[3][6].jump_x = 0;
	board[3][6].jump_y = 0;
	board[3][6].type = E;
	
	board[3][7].data = -1;
	strcpy(board[3][7].text , "{52}");
	board[3][7].jump_x = 4;
	board[3][7].jump_y = 1;
    board[3][7].type = S;
    
	board[3][8].data = 62;
	strcpy(board[3][8].text," ");
	board[3][8].jump_x = 0;
	board[3][8].jump_y = 0;
    board[3][8].type = E;
    
	board[3][9].data = 61;
	strcpy(board[3][9].text," ");
	board[3][9].jump_x = 0;
	board[3][9].jump_y = 0;
	board[3][9].type = E;
////////////////////////////

	board[4][0].data = 51;
	strcpy(board[4][0].text," ");	
	board[4][0].jump_x = 0;
	board[4][0].jump_y = 0;
	board[4][0].type = E;
	
	board[4][1].data = 52;
	strcpy(board[4][1].text,"{77}");
	board[4][1].jump_x = 2;
	board[4][1].jump_y = 6;
	board[4][1].type = E;
	
	board[4][2].data = 53;	
	strcpy(board[4][2].text," ");
	board[4][2].jump_x = 0;
	board[4][2].jump_y = 0;
	board[4][2].type = E;
	
	board[4][3].data = -4;
	strcpy(board[4][3].text," ");
	board[4][3].jump_x = 5;	 
	board[4][3].jump_y = 8;	 
	board[4][3].type = T;
	
	board[4][4].data = 55;
	strcpy(board[4][4].text," ");
	board[4][4].jump_x = 0;  
	board[4][4].jump_y = 0;	
	board[4][4].type = E;
	
	board[4][5].data = 56;
	strcpy(board[4][5].text," ");
	board[4][5].jump_x = 0;
	board[4][5].jump_y = 0;
    board[4][5].type = E;
    
	board[4][6].data = -5;
	strcpy(board[4][6].text ,"{77}");
	board[4][6].jump_x = 2;
	board[4][6].jump_y = 6;
	board[4][6].type = M;
	
	board[4][7].data = 58;
	strcpy(board[4][7].text ," ");
	board[4][7].jump_x = 0;
	board[4][7].jump_y = 0;
    board[4][7].type = E;
    
	board[4][8].data = 59;
	strcpy(board[4][8].text," ");
	board[4][8].jump_x = 0;
	board[4][8].jump_y = 0;
    board[4][8].type = E;
    
	board[4][9].data = -1;
	strcpy(board[4][9].text , "{44}");
	board[4][9].jump_x = 4;
	board[4][9].jump_y = 6;
	board[4][9].type = S;
////////////////////////////////////

	board[5][0].data = -2;
	strcpy(board[5][0].text," ");	
	board[5][0].jump_x = 4;
	board[5][0].jump_y = 5;
	board[5][0].type = B;
	
	board[5][1].data = 49;
	strcpy(board[5][1].text ," ");
	board[5][1].jump_x = 0;
	board[5][1].jump_y = 0;
	board[5][1].type = E;
	
	board[5][2].data = -3;	
	strcpy(board[5][2].text ," ");
	board[5][2].jump_x = 0;    /*for stop penalty*/
	board[5][2].jump_y = 0;	/*for stop penalty*/
	board[5][2].type = P;
	
	board[5][3].data = 47;
	strcpy(board[5][3].text," ");
	board[5][3].jump_x = 0;	 
	board[5][3].jump_y = 0;	 
	board[5][3].type = E;
	
	board[5][4].data = 46;
	strcpy(board[5][4].text," ");
	board[5][4].jump_x = 0;  
	board[5][4].jump_y = 0;	
	board[5][4].type = E;
	
	board[5][5].data =-1;
	strcpy(board[5][5].text ,"{22}");
	board[5][5].jump_x = 7;
	board[5][5].jump_y = 7;
    board[5][5].type = S;
    
	board[5][6].data = 44;
	strcpy(board[5][6].text ," ");
	board[5][6].jump_x = 0;
	board[5][6].jump_y = 0;
	board[5][6].type = E;
	
	board[5][7].data = 43;
	strcpy(board[5][7].text ," ");
	board[5][7].jump_x = 0;
	board[5][7].jump_y = 0;
    board[5][7].type = E;
    
	board[5][8].data = 42;
	strcpy(board[5][8].text ," ");
	board[5][8].jump_x = 0;
	board[5][8].jump_y = 0;
    board[5][8].type = E;
    
	board[5][9].data = 41;
	strcpy(board[5][9].text ," ");
	board[5][9].jump_x = 0;
	board[5][9].jump_y = 0;
	board[5][9].type = E;
////////////////////////////////////

	board[6][0].data = 31;
	strcpy(board[6][0].text ," ");	
	board[6][0].jump_x = 0;
	board[6][0].jump_y = 0;
	board[6][0].type = E;
	
	board[6][1].data = -5;
	strcpy(board[6][1].text ,"{52}");
	board[6][1].jump_x = 4;
	board[6][1].jump_y = 1;
	board[6][1].type = M;
	
	board[6][2].data = 33;	
	strcpy(board[6][2].text ," ");
	board[6][2].jump_x = 0;    
	board[6][2].jump_y = 0;	
	board[6][2].type = E;
	
	board[6][3].data = 34;
	strcpy(board[6][3].text ," ");
	board[6][3].jump_x = 0;	 
	board[6][3].jump_y = 0;	 
	board[6][3].type = E;
	
	board[6][4].data = 35;
	strcpy(board[6][4].text ," ");
	board[6][4].jump_x = 0;  
	board[6][4].jump_y = 0;	
	board[6][4].type = E;
	
	board[6][5].data = -2;
	strcpy(board[6][5].text," ");
	board[6][5].jump_x = 5;
	board[6][5].jump_y = 8;
    board[6][5].type = B;

	board[6][6].data = 37;
	strcpy(board[6][6].text," ");
	board[6][6].jump_x = 0;
	board[6][6].jump_y = 0;
    board[6][6].type = E;
    	
	board[6][7].data = 38;
	strcpy(board[6][7].text," ");
	board[6][7].jump_x = 0;
	board[6][7].jump_y = 0;
    board[6][7].type = E;
    
	board[6][8].data = 39;
	strcpy(board[6][8].text," ");
	board[6][8].jump_x = 0;
	board[6][8].jump_y = 0;
    board[6][8].type = E;
    
	board[6][9].data = -4;
	strcpy(board[6][9].text," ");
	board[6][9].jump_x = 4;
	board[6][9].jump_y = 6;
    board[6][9].type = T;
    	
	////////////////////////////////////

	board[7][0].data = 30;
	strcpy(board[7][0].text," ");
	board[7][0].jump_x = 0;
	board[7][0].jump_y = 0;
	board[7][1].type = E;
	
	board[7][1].data = -2;
	strcpy(board[7][1].text," ");
	board[7][1].jump_x = 6;
	board[7][1].jump_y = 6;
	board[7][1].type = B;
	
	board[7][2].data = 28;	
	strcpy(board[7][2].text," ");
	board[7][2].jump_x = 0;    
	board[7][2].jump_y = 0;	
	board[7][2].type = E;
	
	board[7][3].data = 27;
	strcpy(board[7][3].text ," ");
	board[7][3].jump_x = 0;	 
	board[7][3].jump_y = 0;	 
	board[7][3].type = E;
	
	board[7][4].data = 26;
	strcpy(board[7][4].text," ");
	board[7][4].jump_x = 0;  
	board[7][4].jump_y = 0;	
	board[7][4].type = E;
	
	board[7][5].data = -1;
	strcpy(board[7][5].text , "{12}");
	board[7][5].jump_x = 8;
	board[7][5].jump_y = 1;
    board[7][5].type = S;
    
	board[7][6].data = 24;
	strcpy(board[7][6].text ," ");
	board[7][6].jump_x = 0;
	board[7][6].jump_y = 0;
	board[7][6].type = E;
	
	board[7][7].data = 23;
	strcpy(board[7][7].text ," ");
	board[7][7].jump_x = 0;
	board[7][7].jump_y = 0;
    board[7][7].type = E;
    
	board[7][8].data = 22;
	strcpy(board[7][8].text ," ");
	board[7][8].jump_x = 0;
	board[7][8].jump_y = 0;
    board[7][8].type = E;
    
	board[7][9].data = 21;
	strcpy(board[7][9].text ," ");
	board[7][9].jump_x = 4;
	board[7][9].jump_y = 6;
	board[7][9].type = E;
	////////////////////////////////////

	board[8][0].data = 11;
	strcpy(board[8][0].text ," ");
	board[8][0].jump_x = 0;
	board[8][0].jump_y = 0;
	board[8][0].type = E;
	
	board[8][1].data = 12;
	strcpy(board[8][1].text ," ");
	board[8][1].jump_x = 6;
	board[8][1].jump_y = 6;
	board[8][1].type = E;
	
	board[8][2].data = 13;	
	strcpy(board[8][2].text ," ");
	board[8][2].jump_x = 0;    
	board[8][2].jump_y = 0;	
	board[8][2].type = E;
	
	board[8][3].data = 14;
	strcpy(board[8][3].text ," ");
	board[8][3].jump_x = 0;	 
	board[8][3].jump_y = 0;	 
	board[8][3].type = E;
	
	board[8][4].data = 15;
	strcpy(board[8][4].text ," ");
	board[8][4].jump_x = 0;  
	board[8][4].jump_y = 0;	
	board[8][4].type = E;
	
	board[8][5].data = 16;
	strcpy(board[8][5].text ," ");
	board[8][5].jump_x = 0;
	board[8][5].jump_y = 0;
    board[8][5].type = E;
    
	board[8][6].data = -5;
	strcpy(board[8][6].text , "{28}");
	board[8][6].jump_x = 7;
	board[8][6].jump_y = 2;
	board[8][6].type = M;
	
	board[8][7].data = 18;
	strcpy(board[8][7].text ," ");
	board[8][7].jump_x = 0;
	board[8][7].jump_y = 0;
    board[8][7].type = E;
    
	board[8][8].data = 19;
	strcpy(board[8][8].text ," ");
	board[8][8].jump_x = 0;
	board[8][8].jump_y = 0;
    board[8][8].type = E;
    
	board[8][9].data = 20;
	strcpy(board[8][9].text," ");
	board[8][9].jump_x = 0;
	board[8][9].jump_y = 0;
    board[8][9].type = E;
	////////////////////////////////////

	board[9][0].data = 10;
	strcpy(board[9][0].text," ");	
	board[9][0].jump_x = 0;
	board[9][0].jump_y = 0;
	board[9][0].type = E;
	
	board[9][1].data = 9;
	strcpy(board[9][1].text," ");
	board[9][1].jump_x = 0;
	board[9][1].jump_y = 0;
	board[9][1].type = E;
	
	board[9][2].data = 8;	
	strcpy(board[9][2].text," ");
	board[9][2].jump_x = 0;    
	board[9][2].jump_y = 0;	
	board[9][2].type = E;
	
	board[9][3].data = -5;
	strcpy(board[9][3].text , "{11}");
	board[9][3].jump_x = 8;	 
	board[9][3].jump_y = 0;	 
	board[9][3].type = M;
	
	board[9][4].data = -1;
	strcpy(board[9][4].text , "{1}");
	board[9][4].jump_x = 9;  
	board[9][4].jump_y = 9;	
	board[9][4].type = S;
	
	board[9][5].data = 5;
	strcpy(board[9][5].text ," ");
	board[9][5].jump_x = 0;
	board[9][5].jump_y = 0;
	board[9][5].type = E;
	
	board[9][6].data = 4;
	strcpy(board[9][6].text," ");
	board[9][6].jump_x = 0;
	board[9][6].jump_y = 0;
	board[9][6].type = E;
	
	board[9][7].data = 3;
	strcpy(board[9][7].text," ");
	board[9][7].jump_x = 0;
	board[9][7].jump_y = 0;
    board[9][7].type = E;

	board[9][8].data = 2;
	strcpy(board[9][8].text , " ");
	board[9][8].jump_x = 0;
	board[9][8].jump_y = 0;
    board[9][8].type = E;
    
	board[9][9].data = 1;
	strcpy(board[9][9].text,"(start)");
	board[9][9].jump_x = 0;
	board[9][9].jump_y = 0;
    board[9][9].type = E;	
	
	if(board[*x][*y].type != E){
	    *x = board[*x][*y].jump_x;
	    *y = board[*x][*y].jump_y;
	    
	}
	
	printf(" Now you are here %d\n", board[*x][*y].data);
	
	for(i = 0; i <10; i++){
		
		for(j = 0; j <10; j++){
		
			if(board[i][j].data == 1){
				printf("%d",board[i][j].data);
				printf("%s\t",board[i][j].text);			
			}
			
			else if(board[i][j].data < 100 && board[i][j].data > 1 ){	
				
				if(board[i][j].data != -1 || 
				board[i][j].data != -2 || 
				board[i][j].data != -3 || 
				board[i][j].data != -4 || 
				board[i][j].data != -5)
				printf("%d\t",board[i][j].data);	
			}
			else if(board[i][j].data == 100){
			
				printf("%d",board[i][j].data);
				printf("%s\t",board[i][j].text);
			}			
			
			else if(board[i][j].type == S ){				
				printf("S");
				printf("%s\t",board[i][j].text);			
			}	
			else if(board[i][j].type == B ){				
				printf("B\t");			
			}
			else if(board[i][j].type == P ){				
				printf("P\t");			
			}
			else if(board[i][j].type == T ){				
				printf("T\t");			
			}
			else if(board[i][j].type == M ){				
				printf("M");			
				printf("%s\t",board[i][j].text);
			}
			
		}
		printf("\n");
	}
	
	
}


int single(blockk board[][10], int *x, int *y){

	int i, control, dice = 0;
	
	dice = rand()%6+1;
	printf("dice == %d\n",dice);
		
	if(board[*x][*y].data == 100){
		printf("now you are in 100\n");
		return 1;
	}
	
	else if(board[*x][*y].data + dice == 100){
		printf("now you are in 100\n");
		return 2;
	}
	
	else if(board[*x][*y].data < 100){
			    
	    write(board ,x,y);
	  
	    
	    for(i = 0; i < dice ; i++){
    	    	 
	        if(*x %2 == 0){
	            if(*y<9)            
	                *y=*y+1;
	            if(*y == 9){
	                *x=*x-1;
	            }	      
	        }
	        else if (*x %2 == 1){
                *y=*y-1;	        
	            if(*y == 0 )
	                *x=*x-1;
	        }
	        	    
	    }	
	   	if(board[*x][*y].data + dice != 100)
			return single(board, x, y);

	}
	else if(board[*x][*y].data > 100){
		
		return single(board, x, y-dice);
	
	}
	
			
		

}













