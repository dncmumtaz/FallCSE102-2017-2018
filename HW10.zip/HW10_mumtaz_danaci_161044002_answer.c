									/* MUMTAZ DANACI     */ 
									/* 161044002    	 */	
									/*HW09 - prime number*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct razik{	/*razik is any name of variable, it is not special name*/
	int value;
	struct razik *next;
}R1; 

int read();
void funcb();
void funca(R1 *root ,R1 *tail ,R1 *new);
int prime_number(int reed);

int main(){		/*the main funtion*/
	R1 *root = NULL, *tail = NULL, *new;
	funcb();
	funca(&*root, &*tail, &*new);
	return 0;
}


int read(FILE * open){			/*the read function*/
	
	char str[60];
	int number;
	
	fgets(str,1024,open);
	number = atoi(str);

	
	return number;
}

void funcb(){ /*the dynacmic array funtion*/
	
	clock_t start_two,finish_5_two,finish_75_two,finish1_two,finishprint_two;
	
	double second1,second2,second3,second4;
	
	FILE *dynamic;	
	FILE  *open;
	int i, k, reed, count = 0, result;
	int *arr = (int *)calloc(1000000,sizeof(int));
	open = fopen("data.txt","r");
	dynamic = fopen("output_prime_dynamic_array.txt","a");
	start_two = clock(); 
	for(int i =0 ; i<1000000; i++){
		
		reed = read(&*open);
		arr[i] = reed;
		result = prime_number(reed);
		if(result == 1)
				//fprintf(dynamic,"%d\n",arr[i]);		
		if(i==500000) finish_5_two =clock();
		if(i==750000) finish_75_two =clock();
	}
	
	finish1_two = clock();
	second1 = (double)(finish_5_two-start_two)/CLOCKS_PER_SEC;
	second2 = (double)(finish_75_two- start_two)/CLOCKS_PER_SEC;
	second3 = (double)(finish1_two-start_two)/CLOCKS_PER_SEC;
	
	fprintf(dynamic,"\n 1 and 500k:%lf",second1);
	fprintf(dynamic,"\n1 and 750k:%lf",second2);
	fprintf(dynamic,"\n1 and 1m:%lf",second3);
	
	finishprint_two = clock();
	
	second4=(double)(finishprint_two-start_two)/CLOCKS_PER_SEC;
	fprintf(dynamic,"\n file time:%lf",second4);
	
	
	free(arr);	
	fclose(dynamic); 
	fclose(open);
	
	
}
void funca(R1 *root ,R1 *tail ,R1 *new){/*the link-list function*/
	
	int result;
	FILE  *open;
	FILE *link;
	link = fopen("output_prime_LiknedList.txt","a");
	open = fopen("data.txt","r");
	
	clock_t start_one,finish_5_one,finish_75_one,finish1_one,finishprint_one;
	
	double second1,second2,second3,second4;
	
	start_one = clock(); 
	for(int i =0 ; i<1000000; i++){
	
		new = (R1*)malloc(sizeof(R1));		
		new->value = read(&*open);	
		new->next = NULL;	
		if(root == NULL ){
			root = new;
			tail = root;	
		}			
		else{
			tail->next = new;
			tail  = tail->next;	
		}
		
		result = prime_number(new->value);
		if(result == 1)
			fprintf(link,"%d\n",new->value);
			
		if(i==500000) finish_5_one =clock();
		if(i==750000) finish_75_one =clock();
					
	}
	
	finish1_one = clock();
	second1 = (double)(finish_5_one-start_one)/CLOCKS_PER_SEC;
	second2 = (double)(finish_75_one- start_one)/CLOCKS_PER_SEC;
	second3 = (double)(finish1_one-start_one)/CLOCKS_PER_SEC;
	
	fprintf(link,"\n 1 and 500k:%lf",second1);
	fprintf(link,"\n1 and 750k:%lf",second2);
	fprintf(link,"\n1 and 1m:%lf",second3);
	
	finishprint_one = clock();
	
	second4=(double)(finishprint_one-start_one)/CLOCKS_PER_SEC;
	fprintf(link,"\n file time:%lf",second4);
	
	free(new);
	fclose(open);
	
	
}

int prime_number(int reed){ /*the prime number function*/
		int k, result = 0;
		if( reed > 1){
			for(k = 2; k <reed; k++){
				if(reed%k ==0){
					result = 0;
					return -1;				
				}							
			}
				if(result != 1){
					printf("%d\n",reed);	
					return 1;	
				}				
		}
		else 
			return 0;			
}













