						/*MUMTAZ DANACI*/
						/*161044002    */
						/*HW06			*/	
#include <stdio.h>
void menu();
void encrypt_open_msg();						/*the functions*/
void decrypt_secret_msg();
int find_size_of_line(char line[]);
void reverse_line(char line[], int line_lenght);

int main(){		/*the main function*/
	menu();

}
void menu(){		/*the menu function*/
	int number = 3;		/*its an any number*/
	
	while( number != 0){	/*the loop for menu*/
		
	printf("  *********\n");
	printf("*************\n");
	printf("1. Encrypt\n");
	printf("2. Decrypt\n");
	printf("0. Exit\n    ");
	printf("Choice: ");
	scanf("%d",&number);
	printf("*************\n");
	printf("  *********\n");

	
	switch(number){		/*the options*/
	
		case  1:
			encrypt_open_msg();
			break;	
		case  2:
			decrypt_secret_msg();
			break;
		case  0:
			break;	
		default :
			printf("wrong number!!!!!\n");
			break;
	
		}
	
	}
}


void encrypt_open_msg(){		/*the encrypt function*/

	int i, j,k=0,l,m,  temp1 ;	
	char line[1024];	
	int line_lenght;
	int key;
	char  temp, temp2;
	
	printf("enter key : ");
	scanf("%d",&key);	/*this row gets a number from user */
	printf("\nKey: %d\n",key);
	
	FILE *open;
	FILE *write;
	
	
	open = fopen("open_msg.txt","r");	
	write = fopen("secret_msg.txt","w");
	while(fgets(line,2014,open) != NULL ){		/*for whole text*/
		
		line_lenght = find_size_of_line( line);	
		reverse_line( line, line_lenght);

		for(i = 1; i< line_lenght; i++){
		
			temp = line[i];
			
		    if(line[i] =='.'){
		    	line[i]='*';
				printf("*");
			}
			
			else if(line[i] == ' '){
				line[i] = '_';
				printf("_");
			}
			else if(line[i]>='a' && line[i]<='z'){
				temp2=(((line[i] - 19)%26)-key+26)%26;
				line[i] = temp2 + 'a';
				 
				printf("%c",line[i]);	
			}
			fprintf(write,"%c",line[i]);
	
		}
		fprintf(write,"\n");
		printf("\n");
		
	}

	fclose(open);
	
	for(j = 0 ; j < line_lenght; j++){
		
	}
	
	fclose(write);

}

void decrypt_secret_msg(){ 	/*the decrypt funtion*/

	int i, j,k=0,l,m,  temp1 ;
	char line[1024];	
	int line_lenght;
	int key;
	char board[1024];
	char temprory_line[1024], temp;
	
	printf("enter key : ");
	scanf("%d",&key);	/*this row gets a number from user */
	printf("\nKey: %d\n",key);
	
	FILE *open;
	FILE *write;
	
	
	write = fopen("open_msg.txt","w");
	open = fopen("secret_msg.txt","r");
	while(fgets(line,2014,open) != NULL ){		/*for whole text*/
		
		line_lenght = find_size_of_line( line);	
		reverse_line( line, line_lenght);

		for(i = 1; i< line_lenght; i++){
		
		    if(line[i] =='*'){
		    	line[i]='.';
				printf(".");
			}
			else if (line[i] == '\n');
			
			else if(line[i] == '_'){
				line[i] = ' ';
				printf(" ");
			}
			else if(line[i]>='a' && line[i]<='z') {
				temp=(((line[i] - 19)%26)+key)%26;
				line[i] = temp + 'a';
				 
				printf("%c",line[i]);		
			}
			fprintf (write,"%c",line[i]);
		}
		fprintf(write,"\n");
		printf("\n");
	}

	fclose(open);
	fclose(write);

}
int find_size_of_line(char line[]){		/*find size of line*/
	int i;

	for(i = 0; line[i] != '\0'; i++) ;
	return i; 
		
}


void reverse_line(char line[], int line_lenght){/*the reverse function*/
		
	int i, l, j=1, k;
	char temp, temp1;

	for(i = 0; i < line_lenght/2 ; i++){	/*for lines*/
		
		temp = line[i];						/*the swap rows.*/
		line[i] = line[line_lenght-j ] ; 
		line[line_lenght-j ] = temp;		
		j++;
	
	}
		


}





















