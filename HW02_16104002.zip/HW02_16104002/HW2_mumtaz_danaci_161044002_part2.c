										/*MUMTAZ DANACI*/
										/*161044002*/

#include <stdio.h>   /*The standart library*/
int main (){
	int a, number;   
	printf("Enter a number between 23 and 98760 : ");/*I wanted to value from user.*/
	scanf("%d",&number);				/*I took value from user.*/	
	if (number>10000 && number<98761){
	a=number/10000;					/*I */
	printf("The Fifth Digit:%d\n",a);
	number=number-(a*10000);
		}
		if(number<10000){
	a=number/1000;
	printf("The Fourth Digit:%d\n",a);
	number=number-(a*1000);
	}													
	if (number<1000){
		a=number/100;
		printf("The third Digit:%d\n",a);
		number=number-(a*100);
	}
	if(number<100) {
		a=number/10;
		printf("The secon Digit:%d\n",a);
		number=number-(a*10);
		}
	if(number<10){
	printf("The First Digit:%d\n",number);
	}
return 0;
}
