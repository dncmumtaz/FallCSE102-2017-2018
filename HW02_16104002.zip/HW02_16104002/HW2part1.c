						/*MUMTAZ DANACI*/
						/*161044002*/
						/*Part1--Purpose of this program is I.Show most successful student*/
						/*II.Show most unsuccessful student,*/
						/*III.List the number of students for each letter grade,*/
						/*IV.Show calculated average grade*/
						/*V.Show all four options data.*/
#include <stdio.h>
#include <stdlib.h>			/*The necessary libraries*/
int main(){
	int a=0 ,A=0,B=0,C=0,D=0,F=0,max=0,min=100, maxindex, minindex, number_ofstudent,total=0, grade; /*These are the integer i use. */
	double average;   
	srand(40); /*i used them to assign random values.*/	
	while(a!=1){
		printf("\nENTER STUDENT COUNT:"); /*I wanted value from user.*/
		scanf("%d",&number_ofstudent);
		if(number_ofstudent>3 && number_ofstudent<50){ 
			a=1;}
		else
			printf("\nNot in Range!");
	}
	int range=0;
	for(a=1	;a<=number_ofstudent;a++){	
		grade=rand()%101; /*Rand Functions assigned value to grade  */
		printf("\t%d",grade);
		total=grade+total; /*I used total integer for calculet to average value.*/
		range++;
		if(max<grade){
			max=grade;      /*I used max and maxindex for first option*/
			maxindex=range;
		}
		if(min>grade){
			min=grade;		/*I used min and minindex for second option*/
			minindex=range;
		}	
		if(grade>90 && grade<100 ){
			A++;
		}
		else if(grade>80 && grade<90 ){  /*the fourteen row for second option*/
			B++;
		}
		else if(grade>70 && grade<80){
			C++;	
		}
		else if (grade>60 && grade<70 ){
			D++;
		}
		else
			F++;						
	}
		average=total/number_ofstudent;	/*this row calculeted average.*/
	int number;
	while(number!=-1){
		printf("\n1.Most succesful student:\n2.Most unsuccesful student:\n 3.Letter grade statistic\n4.calculate average:\n5.Show all data:\n");
		printf("\nenter a number:");
		scanf("%d",&number);
		switch(number){
			case -1 :	
				printf("\t");				
				break;
			case 1 :		/*case 1 for selection 1.*/
				printf("Most succesful student:");				
				if (max>90)
					printf("Most succesful student:\n index:%d\n grade:%d\n letter grade:A",maxindex,max);
				else if(max>80)
					printf("Most succesful student:\n index:%d\n grade:%d\n letter grade:B",maxindex,max);
				else if(max>70)
					printf("Most succesful student:\n index:%d\n grade:%d\n letter grade:C",maxindex,max);
				else if (max>60)
					printf("Most succesful student:\n index:%d\n grade:%d\n letter grade:d",maxindex,max);
				else
					printf("Most succesful student:\n index:%d\n grade:%d\n letter gradeF:",maxindex,max);
					
					break;
			case 2:			/*selection 2*/
				printf("Most unsuccesful student:");
				if(min<60)
					printf("Most unsuccesful student:\n index:%d\n grade:%d\n letter grade:F",minindex,min);
				else if(min<70)
					printf("Most unsuccesful student:\n index:%d\n grade:%d\n letter grade:D",minindex,min);
				else if(min<80)
					printf("Most unsuccesful student:\n index:%d\n grade:%d\n letter grade:C",minindex,min);
				else if(min<90)
					printf("Most unsuccesful student:\n index:%d\n grade:%d\n letter grade:B",minindex,min);
				else if(min<100)
					printf("Most unsuccesful student:\n index:%d\n grade:%d\n letter grade:A",minindex,min);
					break;
			case 3 :		/*selesction 3*/
				printf("Letter grade statistic");
				printf("%d student got letter grade 'A'\n",A);
				printf("%d student got letter grade 'B'\n",B);
				printf("%d student got letter grade 'C'\n",C);
				printf("%d student got letter grade 'D'\n",D);
				printf("%d student got letter grade 'F'\n",F);				
				break;
			case 4 : 		/*selection 4 */
				printf("calculate average");
				printf("The Average Score Of %d Student %lf",number_ofstudent,average);				
				break;
			case 5 :		/*selection 5*/
				printf("Show all data");
				printf("Most succesful student:\n index:%d\n grade:%d\n letter grade:\n",maxindex,A);
				printf("Most unsuccesful student:\n index:%d\n grade:%d\n letter grade:\n",minindex,A);
				printf("The Average Score Of %d Student %lf\n",number_ofstudent,average);
				printf("%d student got letter grade 'A'\n",A);
				printf("%d student got letter grade 'B'\n",B);
				printf("%d student got letter grade 'C'\n",C);
				printf("%d student got letter grade 'D'\n",D);
				printf("%d student got letter grade 'F'\n",F);				
				break;
			default:
			 printf("False Selection!\n");
		}	
	}
	return 0;
}
