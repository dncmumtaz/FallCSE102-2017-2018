							/*mumtaz danaci*/
							/*161044002*/	
							/*hw09 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct{ 		/* the structure about board*/
    char **map;
    int width;
    int height;
    int flower_x;
    int flower_y;
}Forest;

typedef struct{		/*the structure about botanist */
    int coord_x;
    int coord_y;
    int water_bottle_size;
}Botanist;


int arrlen (char arr[]){		/*the function about lenght of array.*/
    int i = 0,total = 0;
    while(arr[i] != 0){
        total++;
        i++;
    }
    return total;
}


void init_game (Forest *forest, Botanist *botanist){	/*the funtion about initialize of board*/
	FILE *open;
    open = fopen("init.txt","r");
    int len, buffer = 1024;
    int i,j=0,k=0;
	char arr[buffer];

    fscanf (open,"%d",&botanist->water_bottle_size);
    fscanf (open,"%d,%d",&forest->height,&forest->width);
    
    forest->map=malloc(forest->height * sizeof(char*));
    for (i=0 ; i<forest->height ; i++)
        forest->map[i]=malloc(forest->width * sizeof(char*));
       
    fgets(arr, buffer, open);
    while (fgets(arr, buffer, open) != NULL){
 	    len = arrlen(arr);
        for (i=0 ; i<len ; i++){
            if (arr[i] != ','){
                forest->map[j][k] = arr[i];
                k++;
            }
       }
       j++;
       k=0;
       
    }
    for(i=0; i<forest->height ; i++){
    	for(k = 0; k<forest->width; k++){
    		if (forest->map[i][k] == 'F'){
                forest->flower_x = i;
                forest->flower_y = k;  
         		
            }
			if(forest->map[i][k] == 'B'){
		    	botanist->coord_x = i;
		        botanist->coord_y = k;
					
		    	}    	    	
    	}
    	    		
    
    }   

    fclose(open);
    printf("botan%d, forest%d\n",botanist->coord_x,botanist->coord_y);
     printf("xxxxxxxxx%d,yyyyyy%d\n",forest->flower_x,forest->flower_y);
}

void print_map (Forest forest){			/*the funtion about print of map*/
    int i,j;
    for (i=0 ; i<forest.height ; i++){
        for (j=0 ; j<forest.width ; j++){
            printf ("%c",forest.map[i][j]);
        }
        printf ("\n");
    }
}

void search (Forest *forest,int x, int y,int water){	/*the funtion about searching on board*/

    int dice;
    dice = rand()%4;
    if (x==forest->flower_x && y==forest->flower_y){
        //print_map(*forest);
        printf ("I have fount it on (%d,%d)\n",forest->flower_x,forest->flower_y);
        return ;
    }
    else if (water<=0){
    	//print_map(*forest);
        printf ("Helm me at (%d,%d)\n",x,y);
        return;
    }
    
    if ((dice == 0 && x+1 < forest->height )&& forest->map[x+1][y] != '#'  ){
    	
         return search(&*forest, x+1, y, water-1);
       
    }
    
    else if ((dice == 1 && x-1 >-1 )&& forest->map[x-1][y] != '#'  ){
        return search(&*forest, x-1, y, water-1);

    }
    
    else if ((dice == 2 && y-1 >0 )&& forest->map[x][y+1] != '#'){
        return search(&*forest, x, y-1, water-1);
        
    }
    
    else if ((dice == 3 &&  y+1< forest->width )&&  forest->map[x][y-1] != '#'){
        return search(&*forest, x, y+1, water-1);
    }
    
    else 
        return search(&*forest, x, y, water);
    

}


int main(){    /*the main funtion*/
    Forest forest;
    Botanist botanist;
    srand (time(NULL));
    init_game(&forest,&botanist);
    print_map(forest);
    search(&forest, botanist.coord_x, botanist.coord_y, botanist.water_bottle_size);
   
    return 0;
}











































