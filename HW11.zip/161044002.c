									/* MUMTAZ DANACI       */ 
									/* 161044002    	   */	
									/*HW11 - HOTEL DATABASE*/
#include <stdio.h>
#include <stdlib.h>

typedef struct rooms{	/*the room property*/
	int room_number;	
	int room_capacity;
	int room_floor;
	struct customer *info;
	struct rooms *next;
}R1;

typedef struct customer{
	int cnumber;
	char name[30];
	char surname[30];
	int age;
	char gender;
	struct customer *next;
}C1;

R1 *root = NULL, *tail = NULL, *new;
C1 *head = NULL, *current = NULL, *temp;


int add_room_to_end();			/*The function add a room to the end of the room list.*/
void add_room_after_room_number ();	/*The function add a room to after the given room
number. If the given room does not exists, add it to the end of the list.*/
void add_customer_to_end();	/*The function add a customer to the end of the partial customer
list.*/
void link_customers_to_room();/*The function adds partial customer list to a room*/
void remove_room ();	/*The function removes the room indicated by the room number.*/
void show_vacancy();	/*The function list all available rooms that don’t have any customer.*/
void get_by_floor();	/*The function lists the rooms with the given floor number.*/
void print_list ();	/*The function prints the room list with customers*/



int main(){		/*the main funtion*/
	
	add_room_to_end();
	add_customer_to_end();
	//print_list ();
	//get_by_floor();
	//link_customers_to_room();
	// get_by_floor();
	//add_room_after_room_number ();
	//show_vacancy();
	//remove_room ();
	return 0;
}



int add_room_to_end(){	/*The function add a room to the end of the room list.*/

	FILE * room;
	room = fopen("rooms.txt","r");
	add_customer_to_end();
	int total =0;
	char a ;
	do{	
		total++;
		new = (R1*)malloc(sizeof(R1));	
		a = fscanf(room,"%d,%d,%d", &new->room_number, &new->room_capacity, &new->room_floor);			
		new->next = NULL;		
		if(root == NULL ){
			root = new;
			tail = root;	
		}			
		else{
			tail->next = new;
			tail  = tail->next;	
		}
		
		printf("%d,%d,%d\n",new->room_number, new->room_capacity, new->room_floor);

		
		free(new);
	}while( a != EOF);	
	
	return total;
}
void add_room_after_room_number (){	/*The function add a room to after the given room
number. If the given room does not exists, add it to the end of the list.*/
	

}
void add_customer_to_end(){	/*The function add a customer to the end of the partial customer
list.*/
	FILE *customer;
	customer = fopen("customers.txt","r");

	char  a;
	do{	
		temp = (C1*)malloc(sizeof(C1));
		a = fscanf(customer,"%d,%s %s,%d,%s",&temp->cnumber,temp->surname,temp->name,&temp->age,temp->gender);		
		temp->next = NULL;
		if(head == NULL){
			head = temp;
			current = head;
		}
		else{
			current->next = temp;
			current = current->next;
		}			
		//printf("%d,%s %s\n",temp->cnumber,temp->surname,temp->name);
		
		link_customers_to_room();
		free(temp);
	}while(a != EOF);
	
}
void link_customers_to_room(){	/*The function adds partial customer list to a room*/
	
	tail = root;
	while(tail != NULL ){	
		tail = tail->next;
		if(tail->room_number == temp->cnumber){
			tail->info = temp;
		}
		
	}
	
}
void remove_room (){	/*The function removes the room indicated by the room number.*/
		
}
void show_vacancy(){		/*The function list all available rooms that don’t have any customer.*/

	tail = root;
	while( tail->next != NULL){
		if(tail->info == NULL){
			printf("vacancy room:%d",tail->room_number);
		}
	}
}
void get_by_floor(){		/*The function lists the rooms with the given floor number.*/
	int k=0, number;
	printf("which floor do you want to list?");
	scanf("%d",&number);
	tail = root;
	while( tail->next != NULL){
		
		if(tail->room_floor == number){
			printf("%d\n",new->room_number);				
			
		}
		tail = tail->next;
	
	}
}
void print_list (){		/*The function prints the room list with customers*/
	tail = root;
	while( tail->next != NULL){
		printf(" Room %d(Floor%d-capacity%dx):",new->room_number,new->room_floor,new->room_capacity);
		tail = tail->next;		
	}
}


































































